# Productfeed AI Mode skills — installatiepakket

6 nieuwe productfeed-skills voor Google's conversational / AI Mode shopping-attributen,
plus de bijgewerkte orchestrator die ze in de juiste volgorde aanroept.

## Inhoud

| Map | Attribuut | Aanpak |
|---|---|---|
| `productfeed-question-and-answer/` | `question_and_answer` | Generatief, conservatief (alleen harde feiten). Group attr, ≤30 pairs, 10k char-cap, Sheets-escaping. |
| `productfeed-document-link/` | `document_link` | Map-and-validate PDF-URL-kolom. Verzint nooit URL's. |
| `productfeed-related-product/` | `related_product` | Cross-product. Explicit-kolommen > heuristiek. |
| `productfeed-item-group-title/` | `item_group_title` | Afgeleide gemeenschappelijke groepstitel per `item_group_id`. |
| `productfeed-variant-option/` | `variant_option` | Extractie van variërende dimensies per variant. |
| `productfeed-popularity-rank/` | `popularity_rank` | Validate bestaande, of compute percentiel uit sales/quantity. Verzint nooit. |
| `productfeed-orchestrator/` | — | Bijgewerkte orchestrator (Phase 5 toegevoegd, Category 4, checks 8–11). |

## Installatie

Plaats de 6 nieuwe `productfeed-*` mappen in je skills-directory (`/mnt/skills/user/`),
en **vervang** je bestaande `productfeed-orchestrator/SKILL.md` door de versie in dit pakket.

> Let op: de orchestrator hier is een volledige vervanging. Als je sinds deze build zelf
> wijzigingen in de orchestrator hebt gemaakt, diff dan eerst voordat je overschrijft.

## Wat er in de orchestrator is gewijzigd (8 plekken)

1. `description` + intro: 25 → 31 skills, AI-mode attributen genoemd
2. `COLUMN_CANDIDATES`: +6 attributen + bronkolommen (manual_url, units_sold, etc.)
3. Nieuwe **Category 4**-tabel (mixed behavior van de AI-mode attributen)
4. **Phase 5** toegevoegd aan execution order, met dependency-notities
5. Step 6 wiring: Q&A `exclude`-parameter + item_group_id-vereiste voor variant-skills
6. `OUTPUT_COLUMNS`: +6 → 41 attributen
7. Step 7.5: cross-checks 8–11 + referentietabel
8. Step 8 rapport, Key rules (regel 12), guardrails-sectie

## Nog open (optioneel)

`question_and_answer` heeft volledige NL + EN Q&A-templates; DE/FR/IT/ES/PT staan als
stub (zelfde keys, strings nog vertalen). Aanvullen wanneer je veel anderstalige feeds draait.
